public enum CombinationResultStatus
{
    SuccessNewElement,
    AlreadyDiscovered,
    NoMatch
}
